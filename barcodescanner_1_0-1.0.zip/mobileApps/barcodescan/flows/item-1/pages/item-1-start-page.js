define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    _showBarcodeScanner(arg1) {
      console.log('In ******************************** ');
      var barcodeScannerPromise = new Promise(function (resolve, reject) {
            window.cordova.plugins.barcodeScanner.scan
                (function (result) {
                  console.log(' Start ******************* ');
                  console.log(result.text);
                  alert(result.text);
                  
                    resolve(result.text);                    
                }, 
                function (err) {
                  console.log(' Error ******************* ');
                  console.log('Error in the code scanning:'+err);
                  alert(err);
                    console.error(err);
                reject(err);
            });
        });
        return barcodeScannerPromise;
      
    }
  }

  return PageModule;
});
