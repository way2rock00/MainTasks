define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printdata(arg1) {
      console.log("arg1:::::::::::::",arg1);
    }
  }

  return PageModule;
});
