define([], () => {
  'use strict';

  class PageModule {
  
  setValue(arg1,arg2) {
      console.log('In setValue');
      console.log('Cancel All Flag',arg1);
      console.log('Cancel Item Flag',arg2);
      
    }
    
    assignItemCancelFlagFunc(adp, flagVal, index, val){
      if(val==1)
      {for( var i=0;i<adp.length;i++)
      {
        if(i == index)
        {
          adp[i].CancelFlag = flagVal;
          break;
        }
      }
      console.log('adp value after flag update:', adp);
    }
   else if( val==2)
    {
      for( var j=0;j<adp.length;j++)
      {
        adp[j].CancelFlag = 'false';
      }
      console.log('initial adp value:', adp);
    }
      return adp;
      }
    
    seeValue(arg1)
    {
      
      console.log('Printing Array ************');
      console.log('ADP Current Value:', arg1);
      console.log('Printing Pick Array ************',arg1[0].pickLines);
      return arg1[0].pickLines;
    }
  

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printADPData(arg1, arg2) {
      console.log('ADP Data: ' , arg1);
      for(var i =0; i< arg1.length;i++){
        
        arg1[i].CancelFlag = arg2;
      }
      console.log('arg2', arg2);
      console.log('******** Test ********',arg1);
      return arg1;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    testSwitchPrint(arg1,arg2,arg3,arg4) {
      console.log('In testSwitchPrint arg1:',arg1);
      console.log('In testSwitchPrint arg2:',arg2);
      console.log('In testSwitchPrint arg3:',arg3);
      console.log('In testSwitchPrint arg4:',arg4);
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    populatePickSlipADP(pickSlipDetailsResponse, orgID) {
      var pickLines=[];
      var pickSlipArray=[];
       for(var element of pickSlipDetailsResponse )
       {
         console.log('In testSwitchPrint arg1:', element.Order, element.Organization, element.PickSlip, orgID);
         pickLines=element.pickLines;
        
         for(var lineElement of pickLines)
         {
                 var pickSlipObj={};
            var Id =  Math.floor(Math.random() * 100);
            pickSlipObj.UID=Id;
             pickSlipObj.Order = element.Order;
             pickSlipObj.Organization=element.Organization;
             pickSlipObj.OrganizationID=orgID;
             pickSlipObj.PickSlip=element.PickSlip;
               console.log('In testSwitchPrint arg1:', lineElement.Item, lineElement.PickSlip, lineElement.PickSlipLine,
               lineElement.UOM,lineElement.SourceSubinventory,lineElement.SourceLocator,lineElement.RequestedQuantity,
               lineElement.inventoryAttributesDFF[0].projectId,lineElement.inventoryAttributesDFF[0].taskId);
               
               pickSlipObj.Item = lineElement.Item;
               pickSlipObj.UOM=lineElement.UOM;
               //pickSlipObj.SourceSubinventory=lineElement.SourceSubinventory;
              // pickSlipObj.SourceLocator=lineElement.SourceLocator;
              pickSlipObj.SourceSubinventory='STORAGE';
              pickSlipObj.SourceLocator='300000002255255'; 
               pickSlipObj.RequestedQuantity=lineElement.RequestedQuantity;
                pickSlipObj.PickedQuantity=0;
                pickSlipObj.projectID = '300000003170105'; 
                pickSlipObj.taskID = '100000004357330';
              // pickSlipObj.projectID = lineElement.inventoryAttributesDFF[0].projectId;
               //pickSlipObj.taskID = lineElement.inventoryAttributesDFF[0].taskId;
               pickSlipObj.pickSlipLine=lineElement.PickSlipLine; 
               if(lineElement.Item == '218')
                 {
                   pickSlipObj.ItemID = '100000002793044';
                    pickSlipObj.SourceSubinventory='STORAGE';
              pickSlipObj.SourceLocator='300000002255255'; 
                 }
                else if(lineElement.Item == '218A')
                {
                    pickSlipObj.ItemID = '300000004200024';
                     pickSlipObj.SourceSubinventory='AATRX';
              pickSlipObj.SourceLocator=''; 
                }
               pickSlipArray.push(pickSlipObj); 
     
         }
       }
       console.log("array:", pickSlipArray);
       return pickSlipArray;
    }
    
    
  ////////////////////////////
  
    
     getAvailableQuantity(itemQtyList) {
      var responseObject=new Object();
       var data = [];
       
      
       var totalQuantity = 0;
       

       
        console.log('response', itemQtyList);
       for(var element of itemQtyList){
          var obj = {};
              
       var availableQty = 0;

          availableQty = element.PRIMARY_TRANSACTION_QUANTITY - element.PENDING_TRANSACTION_COUNT - element.RESERVED_TRANSACTION_COUNT;
          totalQuantity = totalQuantity + availableQty;
          

          obj.AvailableQuantity =availableQty;
          obj.INVENTORY_ITEM_ID= element.INVENTORY_ITEM_ID ;
          obj.LOCATOR_ID = element.LOCATOR_ID; 
          obj.PROJECT_ID =  element.PROJECT_ID ; 
          obj.SUBINVENTORY_CODE=  element.SUBINVENTORY_CODE;
          obj.ORGANIZATION_ID = element.ORGANIZATION_ID;
          obj.TASK_ID =element.TASK_ID;
         
        data.push(obj);
        
      }
      console.log(data, totalQuantity);
       responseObject.totalQuantity=totalQuantity;
       responseObject.data = data; 
       return responseObject;
    }
    
    ///////////////////////////////////
    
    
    prepareItemListToSubmit(pickLinesList,onhandItemList) {
      var finalObj = {};
      var lineArr = [];
      var tempArray=[];
      var requestType = '';
      var remainingQty = 0;
      console.log('pickLinesList- ',pickLinesList);
     
      console.log("OnHandItemList ",onhandItemList);
      var currDate = this.getFormattedCurrentDate();
      console.log("currDate--",currDate);
      for(var element of pickLinesList){
      
       console.log('ItemId- ',element.ItemID);
       console.log('OrganizationId - ',element.OrganizationID);
          remainingQty = element.PickedQuantity;
        
          console.log("Picking Feedback");
           requestType = 'PICK_FEEDBACK';
         var filterdItemOnhandArr = onhandItemList.filter(function (el) {
         console.log("Filter val->",el.INVENTORY_ITEM_ID,element.ItemID,el.ORGANIZATION_ID,element.OrganizationID);
         return ((el.INVENTORY_ITEM_ID == element.ItemID) && (el.ORGANIZATION_ID == element.OrganizationID))});
         
         for(var onhand of filterdItemOnhandArr){
           
        var obj = {};
       obj.InventoryItemId=element.ItemID;
       obj.ItemNumber = element.Item;
       obj.OrganizationId= element.OrganizationID;
       obj.OrganizationCode=element.Organization;
      
       obj.TransactionUnitOfMeasure=element.UOM;
       obj.TransactionDate=currDate;
       obj.SubinventoryCode=element.SourceSubinventory;
       obj.LocatorId=element.SourceLocator;
       
      
       
           var availableQty = onhand.AvailableQuantity;
           console.log("AvailableQuantity:",availableQty); 
           console.log("remainingQyt--",remainingQty); 
           if(remainingQty>0){
              //This assumes that always project specific line will come first. The ordering of line is done in Report Query.
              if(availableQty>0){              
                if(remainingQty<=availableQty){
                console.log("Object Added when added qty is less then available qty");  
                console.log("onhand.ProjectId",onhand.PROJECT_ID);
                if(onhand.PROJECT_ID != ''){
                console.log("When projet is not null");                 
                obj.TransactionQuantity= (-1*remainingQty)+"";
                obj.ProjectID=element.projectID;
                
                obj.TaskID=element.taskID;
                
                }else{
                console.log("When projet is  null")
                obj.TransactionQuantity= (-1*remainingQty)+"";
                obj.PjcProjectId= element.projectID;
                obj.PjcTaskId=element.taskID;
				       
                } 
                remainingQty=remainingQty-remainingQty;
                tempArray.push(obj);
                console.log('tempArray- ',tempArray); 
                }else{
                console.log("Object Added when added qty is more then available qty");
                console.log("onhand.ProjectId",onhand.ProjectId);
                if(onhand.PROJECT_ID != ''){
                console.log("When projet is not null");                 
                obj.TransactionQuantity= (-1*availableQty)+"";
                obj.ProjectID=element.projectID;
                
                obj.TaskID=element.taskID;
                
                }else{
                console.log("When projet is  null")
                obj.TransactionQuantity= (-1*remainingQty)+"";
                obj.PjcProjectId= element.projectID;
                obj.PjcTaskId=element.taskID;
				       
                }  
                remainingQty=remainingQty-availableQty;
                tempArray.push(obj); 
                console.log('tempArray- ',tempArray);
                }
              }
           }
         }
         
       }
       console.log('final tempArray- ',tempArray);
       
                 lineArr=tempArray; 

      console.log('lineArrt- ',lineArr);
      finalObj={"REQUEST_TYPE" : requestType,
                "TRX_DTL" : {
                  "line" :lineArr
                }
               }
      console.log('finalObj- ',finalObj);
      return finalObj;
    }
    
    ///////////////////////////////////////////////////
    
    getFormattedCurrentDate(){
      var today = new Date(); 
        var dd = today.getDate(); 
        var mm = today.getMonth() + 1; 
        var yyyy = today.getFullYear(); 
        if (dd < 10) { 
            dd = '0' + dd; 
        } 
        if (mm < 10) { 
            mm = '0' + mm; 
        } 
         today = yyyy+'-'+mm+'-'+dd; 
         return today;
    }
    
    /////////////////////////////////////////////////////
    
    createPickLinesADP(pickLinesServiceResponse, org, shipment, pickslip, order) {
      
      var pickLinesArray=[];
       for(var Element of pickLinesServiceResponse )
       {
         console.log('In testSwitchPrint arg1:',order, org, pickslip, shipment);
        
        
                 var pickLinesObj={};
            var Id =  Math.floor(Math.random() * 100);
            pickLinesObj.UID=Id;
             pickLinesObj.Order = order;
             pickLinesObj.Organization=org;
             //pickLinesObj.OrganizationID=orgID;
             pickLinesObj.PickSlip=pickslip;
               //console.log('In testSwitchPrint arg1:', lineElement.Item, lineElement.PickSlip, lineElement.PickSlipLine,
               //lineElement.UOM,lineElement.SourceSubinventory,lineElement.SourceLocator,lineElement.RequestedQuantity,
               //lineElement.inventoryAttributesDFF[0].projectId,lineElement.inventoryAttributesDFF[0].taskId);
               
               pickLinesObj.Item = Element.Item;
               pickLinesObj.UOM=Element.UOM;
               pickLinesObj.SourceSubinventory=Element.SourceSubinventory;
               pickLinesObj.SourceLocator=Element.SourceLocator;
             // pickLinesObj.SourceSubinventory='STORAGE';
              //pickLinesObj.SourceLocator='300000002255255'; 
               pickLinesObj.RequestedQuantity=Element.RequestedQuantity;
                pickLinesObj.PickedQuantity=0;
                //pickLinesObj.projectID = '300000003170105'; 
                //pickLinesObj.taskID = '100000004357330';
              pickLinesObj.projectID = Element.inventoryAttributesDFF[0].projectId;
              pickLinesObj.taskID = Element.inventoryAttributesDFF[0].taskId;
               pickLinesObj.pickSlipLine=Element.PickSlipLine; 
               if(Element.Item == '218')
                 {
                   pickLinesObj.ItemID = '100000002793044';
                    //pickLinesObj.SourceSubinventory='STORAGE';
             // pickLinesObj.SourceLocator='300000002255255'; 
                 }
                else if(Element.Item == '218A')
                {
                    pickLinesObj.ItemID = '300000004200024';
                     //pickLinesObj.SourceSubinventory='AATRX';
             // pickLinesObj.SourceLocator=''; 
                }
               pickLinesArray.push(pickLinesObj); 
     
         }
       
       console.log("array:", pickLinesArray);
       return pickLinesArray;
    }
    

    
  }

  return PageModule;
});
