define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    getSelectedProjectFunction(selectedRowData,selectedRowKey) {
      var responseObject=new Object();
      for (var key in selectedRowData) {
//            console.log('key ',key);
//               console.log('val ',arg1[key]);
          if (selectedRowData.hasOwnProperty(key)) {
            if(key == 'ProjectId'){
             var val3 = selectedRowData[key];
             console.log('set ProjectId ',val3);
             responseObject.ProjectId1=val3;
          }
          if(key == 'ProjectName'){
             var val14 = selectedRowData[key];
               console.log('set ProjectName ',val14);
             responseObject.projectNameSelected=val14;
          }
          if(key == 'ProjectNumber'){
             var val = selectedRowData[key];
             responseObject.projectNumber=val;
           }
           
           if(key == 'OwningOrganizationName'){
             var val2 = selectedRowData[key];
             console.log('val2 ',val2);
             responseObject.OwningOrganizationName=val2;
           }
          if(key == 'Tasks'){
             var val1 = selectedRowData[key];
             responseObject.taskArray=val1;
          }

          
       }
     }   
       return responseObject;
    }
    
        /**
     *
     * @param {String} arg1
     * @return {String}
     */
    pintdatabookout(arg1) {
            console.log("seelct Project List response --> ",arg1);
            console.log('response length',arg1.length);
             for (var key in arg1) {
               var val = arg1[key];   
                 console.log('key - ',key);
                   console.log('val - ',val);  
             }

    }

  }

  return PageModule;
});
