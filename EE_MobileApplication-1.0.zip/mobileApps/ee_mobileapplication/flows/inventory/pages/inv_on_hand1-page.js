define([], () => {
  'use strict';

  class PageModule {
    
     printEPData(arg1) {
       console.log('Printing Data')
      console.log(arg1);
    }
    
    
    printData(arg1) {
      console.log(arg1);
      var totalQuantity = 0;
      for(var element of arg1){
        console.log('Debug->', element.PRIMARY_TRANSACTION_QUANTITY , element.PENDING_TRANSACTION_COUNT,element.RESERVED_TRANSACTION_COUNT);
        //element.AVAILABLE_QUANTITY = element.PRIMARY_TRANSACTION_QUANTITY - element.PENDING_TRANSACTION_COUNT - element.RESERVED_TRANSACTION_COUNT;
        totalQuantity = totalQuantity + element.PRIMARY_TRANSACTION_QUANTITY;
        console.log('Debug->',element.AVAILABLE_QUANTITY,totalQuantity);
      }
     
      
     
      return totalQuantity;
    }
  
  }

  return PageModule;
});
