define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    pintdatabookout(arg1) {
            console.log("seelct Project List response --> ",arg1);
            console.log('response length',arg1.length);
             for (var key in arg1) {
               var val = arg1[key];   
                 console.log('key - ',key);
                   console.log('val - ',val);  
             }

    }

    /**
     * This method will populate default subinventory and locator for selected item.
     * @param {String} arg1    - default subinventory /location response list
     * @return {String} itemId - Item ID of selected item.
     */
    getSubinventoryAndLocatorForItem(arg1,itemId) {
      console.log("itemId--> ",itemId);
      
           var responseObject=new Object();
            for (var key in arg1) {
               var val = arg1[key];               
                for (var itemKey in val) {
                   var itemval = val[itemKey];
                   if(itemKey === 'INVENTORY_ITEM_ID'){
                     var intVal =   parseInt(itemval);
                     if(intVal == itemId){
                        var locatorVal = val['LOCATOR_ID'];
                        if(locatorVal != -1){
                        var subInvCode= val['SUBINVENTORY_CODE']
                         responseObject.locatorVal=locatorVal;
                         responseObject.invCode = subInvCode; 
                         break;
                       }
                     }
                  }
              }
          }  
           return responseObject;
      }

    /**
     * This method will populate available quantity of selected item at project level+ common project pool and stor all item lines in list to use in final submit case.
     * @param {String} arg1 - bookout itemonhand rest rervice response
     * @return {String}
     */
    getAvailableQuantity(itemQtyList,bookoutHeaderType,bookoutLineType) {
      var responseObject=new Object();
       var data = [];
       data.length = 0;
      
       var totalQuantity = 0;
       

       
//        console.log("bookoutHeaderType in  getAvailableQuantity",bookoutHeaderType,bookoutLineType);
       for(var element of itemQtyList){
          var obj = {};
               var taskNumber="0";
       var projectNumber = 0;
       var availableQty = 0;
//           console.log('Element - ',element);
          availableQty = element.PRIMARY_TRANSACTION_QUANTITY - element.PENDING_TRANSACTION_COUNT - element.RESERVED_TRANSACTION_COUNT;
          totalQuantity = totalQuantity + availableQty;
          if(element.TASK_ID!=""){
            taskNumber = bookoutHeaderType.taskNumber;
          }
           if(element.PROJECT_ID!=""){
            projectNumber = bookoutHeaderType.projectNumberVar;
          }
//           obj= {"AvailableQuantity" :availableQty,"ItemId" : bookoutLineType.itemIdVar ,"LocatorId" : element.LOCATOR_ID, "ProjectId" :  element.PROJECT_ID , "SubInvCode" :  element.SUBINVENTORY_CODE,
//           "ItemNumber" : bookoutLineType.itemNumberVar ,"OrganizationId" : bookoutHeaderType.bsinessUnitVar,"TaskId" :element.TASK_ID,"segment1":bookoutLineType.segment1,
//           "segment2":bookoutLineType.segment2,"segment3":bookoutLineType.segment3,"segment4":bookoutLineType.segment4,"segment5":bookoutLineType.segment5,"projectNumber":projectNumber,
//           "taskNumber":taskNumber};
          obj.AvailableQuantity =availableQty;
          obj.ItemId= bookoutLineType.itemIdVar ;
          obj.LocatorId = element.LOCATOR_ID; 
          obj.ProjectId =  element.PROJECT_ID ; 
          obj.SubInvCode=  element.SUBINVENTORY_CODE;
          obj.ItemNumber = bookoutLineType.itemNumberVar ;
          obj.OrganizationId = bookoutHeaderType.bsinessUnitVar;
          obj.TaskId =element.TASK_ID;
          obj.segment1=bookoutLineType.segment1;
          obj.segment2=bookoutLineType.segment2;
          obj.segment3=bookoutLineType.segment3;
          obj.segment4=bookoutLineType.segment4;
          obj.segment5=bookoutLineType.segment5;
          obj.projectNumber=projectNumber;
          obj.taskNumber=taskNumber;
        data.push(obj);
      }
       responseObject.totalQuantity=totalQuantity;
       responseObject.data = data; 
       return responseObject;
    }

    /**
     * This method will populate item added quantity list added by user
     *
     */
    addItemQuantityToList(QtyAdded,bookoutHeaderType,bookoutLineType,ppeOrToolType,transactionType) {
      console.log('itemId - ',QtyAdded,bookoutHeaderType,bookoutLineType,ppeOrToolType,transactionType);
      var data = [];
      var obj={};
      var Id =  Math.floor(Math.random() * 100)
        if(transactionType =='BOOKOUT'){
          ppeOrToolType = 'G';
        }
          if(transactionType =='BOOKOUT_IN'){
          ppeOrToolType = 'BI';
        }
//         data = [
//           { "AddedQty":parseInt(QtyAdded), "ItemDesc": bookoutLineType.itemDescVar, "ItemId":bookoutLineType.itemIdVar, "ItemNumber":bookoutLineType.itemNumberVar,
//           "OrganizationId" : bookoutHeaderType.bsinessUnitVar,"dstSegment1":bookoutHeaderType.segment1,"dstSegment2":bookoutHeaderType.departmentVar,"dstSegment3":bookoutLineType.account,
//           "organizationCode":bookoutHeaderType.locationCodeVar,"itemUomVar":bookoutLineType.itemPrimaryUOMVar,"pjcOrganizationId":bookoutHeaderType.pjcOrganizationId,
//           "pjcExpenditureTypeId":bookoutHeaderType.expenditureTypeId,"itemType":ppeOrToolType,"segment1":bookoutLineType.segment1,"segment2":bookoutLineType.segment2,
//           "segment3":bookoutLineType.segment3,"locatorId":bookoutLineType.locatorIdVar,"subInvCode":bookoutLineType.subInvCodeVar,"Id":parseInt(Id)},
//           
//       ];
        obj.AddedQty=parseInt(QtyAdded);
        obj.ItemDesc= bookoutLineType.itemDescVar; 
        obj.ItemId=bookoutLineType.itemIdVar; 
        obj.ItemNumber=bookoutLineType.itemNumberVar;
        obj.OrganizationId= bookoutHeaderType.bsinessUnitVar;
        obj.dstSegment1=bookoutHeaderType.segment1;
        obj.dstSegment2=bookoutHeaderType.departmentVar;
        obj.dstSegment3=bookoutLineType.account;
        obj.organizationCode=bookoutHeaderType.locationCodeVar;
        obj.itemUomVar=bookoutLineType.itemPrimaryUOMVar;
        obj.pjcOrganizationId=bookoutHeaderType.pjcOrganizationId;
        obj.pjcExpenditureTypeId=bookoutHeaderType.expenditureTypeId;
        obj.itemType=ppeOrToolType;
        obj.segment1=bookoutLineType.segment1;
        obj.segment2=bookoutLineType.segment2;
        obj.segment3=bookoutLineType.segment3;
        obj.locatorId=bookoutLineType.locatorIdVar;
        obj.subInvCode=bookoutLineType.subInvCodeVar;
        obj.Id=parseInt(Id);
        data.push(obj);
        console.log('return last',data);
     return data;
    }
    
    
     /**
     * This method will populate item added quantity list added by user
     *
     */
    updateItemQuantityToList(QtyAdded,itemQtyAddedList,bookoutLineType) {
       console.log('updateItemQuantityToList itemId - ',QtyAdded,itemQtyAddedList,bookoutLineType);
        var data = null;
        for(var element of itemQtyAddedList){
          console.log('element - ',element);
          
          if(element.ItemId === bookoutLineType.itemIdVar){
            console.log('item matched  old qty- ',element.AddedQty);
            element.AddedQty = QtyAdded;
            return itemQtyAddedList;
          }
          
        }
       
      console.log('return last');
     return itemQtyAddedList;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    populateTransactionType(arg1) {
      console.log('In populateTransactionType',arg1);
      if(arg1 == 'BOOKOUT' )
      return 'Bookout';
      if(arg1 == 'BOOKOUT_TOOLS' )
      return 'Bookout Tools';
      if(arg1 == 'BOOKOUT_PPE' )
      return 'Bookout PPE';
      if(arg1 == 'BOOKOUT_IN' )
      return 'Book In';
    }



    /**
     * This method will use to populate subinventory list on page. it will iterate over response list obj and return distinct seubinventory list to associated action chain
     * @param {String} arg1 - subinvLocator response list
     * @return {String}
     */
    populateSubinventoryList(arg1) {
      console.log("arg1->",arg1);
      var flags = [], subInvListArr = [], l = arg1.length, i;var obj={};
      for( i=0; i<l; i++) {
        if( flags[arg1[i].SUBINVENTORY_CODE]) continue;
          flags[arg1[i].SUBINVENTORY_CODE] = true;
        obj=  {"SUBINVENTORY_CODE" : arg1[i].SUBINVENTORY_CODE,"SUBINVENTORY_ID" : arg1[i].SUBINVENTORY_ID}
          subInvListArr.push(obj);
        }
        console.log("subInvListArr->",subInvListArr);
        return subInvListArr;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    populateLocatorList(subInvCode,subInvLocatorADP) {
       console.log("subInvCode ",subInvCode,subInvLocatorADP);
      var locatorArr = [];
      var obj = {};
      
       for(var element of subInvLocatorADP){
          if(subInvCode === element.SUBINVENTORY_CODE && element.INVENTORY_LOCATION_ID != ''){
            obj = {"INVENTORY_LOCATION_ID" : element.INVENTORY_LOCATION_ID,"LOCATOR" : element.LOCATOR,"SEGMENT1":element.SEGMENT1,"SEGMENT2":element.SEGMENT2,"SEGMENT3":element.SEGMENT3,"SEGMENT4":element.SEGMENT4,"SEGMENT5":element.SEGMENT5};
                    locatorArr.push(obj)
          }
      }
       console.log('locator arr count ->',locatorArr.length);
      return locatorArr;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printVariableData(arg1) {
      console.log('Variable Data', arg1);
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    isRequiredModification(itemQtyAddedList,itemId) {
        for(var element of itemQtyAddedList){
          console.log('element - ',element);
          
          if(element.ItemId === itemId){
               console.log('item matched  old qty- ',element.AddedQty);
            return true;
          }
          
        }
        return false;
    }

    /**
     *
     * @param {String} preapre final request payload to send to bookout item insert OIC service
     * @return {String} request header id and status()
     */
prepareItemListToSubmit(addedItemQtyList,onhandItemList,bookoutHeaderType,transactionType,bookoutLineType) {
      var finalObj = {};
      var lineArr = [];
      var tempArray=[];
      var ItemType='G';
      var requestType = '';
      var remainingQty = 0;
      console.log('addedItemQtyList- ',addedItemQtyList);
      console.log('bookoutHeaderType- ',bookoutHeaderType);
      console.log('onhandItemList - ',onhandItemList);
      console.log('bookoutLineType - ',bookoutLineType);
      console.log("transactionType- ",transactionType);
      var currDate = this.getFormattedCurrentDate();
      console.log("currDate--",currDate);
      for(var element of addedItemQtyList){
      
       console.log('ItemId- ',element.ItemId);
       console.log('OrganizationId - ',element.OrganizationId);
          remainingQty = element.AddedQty;
       if(transactionType == 'BOOKOUT_IN'){
         console.log("BOOKOUT_IN");
         requestType = 'BOOKIN';
       var obj1 = {};
       obj1.InventoryItemId=element.ItemId;
       obj1.ItemNumber = element.ItemNumber;
       obj1.OrganizationId= element.OrganizationId;
       obj1.OrganizationCode=element.organizationCode;
       obj1.ItemType= element.itemType;
       obj1.TransactionUnitOfMeasure=element.itemUomVar;
       obj1.TransactionDate=currDate;
       obj1.SubinventoryCode=element.subInvCode;
       obj1.LocatorId=element.locatorId;
       obj1.LOC_SEGMENT1=element.segment1;
       obj1.LOC_SEGMENT2=element.segment2;
       obj1.LOC_SEGMENT3=element.segment3;
       obj1.LOC_SEGMENT4="";
       obj1.LOC_SEGMENT5="";
       obj1.LOC_SEGMENT6="";
       obj1.LOC_SEGMENT7="";
       obj1.LOC_SEGMENT8="";
       obj1.LOC_SEGMENT9="";
       obj1.LOC_SEGMENT10="";
       obj1.DST_SEGMENT1=element.dstSegment1;
       obj1.DST_SEGMENT2=element.dstSegment2;
       obj1.DST_SEGMENT3=element.dstSegment3;
       obj1.DST_SEGMENT4="";
       obj1.DST_SEGMENT5="";
       obj1.DST_SEGMENT6="";
       obj1.DST_SEGMENT7="";
       obj1.DST_SEGMENT8="";
       obj1.DST_SEGMENT9="";
       obj1.DST_SEGMENT10="";
       obj1.ShipToLocationId=""
       obj1.UseCurrentCost= "Y";
         obj1.TransactionQuantity= remainingQty+"";
         obj1.ProjectID=bookoutHeaderType.projectIdVar;
         obj1.ProjectNumber=bookoutHeaderType.projectNumberVar;
         obj1.TaskID=bookoutHeaderType.taskIdVar;
         obj1.TaskName= bookoutHeaderType.taskNumber; 
         tempArray.push(obj1); 
        } else{
          console.log("BOOKUT");
          if(transactionType == 'BOOKOUT'){
             requestType = 'BOOKOUT';
          }else{
             requestType = 'BOOKOUT_OTHERS';
          }
          
         var filterdItemOnhandArr = onhandItemList.filter(function (el) {
         console.log("Filter val->",el.ItemId,element.ItemId,el.OrganizationId,element.OrganizationId);
         return ((el.ItemId == element.ItemId) && (el.OrganizationId == element.OrganizationId))});
         
         for(var onhand of filterdItemOnhandArr){
           
        var obj = {};
       obj.InventoryItemId=element.ItemId;
       obj.ItemNumber = element.ItemNumber;
       obj.OrganizationId= element.OrganizationId;
       obj.OrganizationCode=element.organizationCode;
       obj.ItemType= element.itemType;
       obj.TransactionUnitOfMeasure=element.itemUomVar;
       obj.TransactionDate=currDate;
       obj.SubinventoryCode=element.subInvCode;
       obj.LocatorId=element.locatorId;
       obj.LOC_SEGMENT1=element.segment1;
       obj.LOC_SEGMENT2=element.segment2;
       obj.LOC_SEGMENT3=element.segment3;
       obj.LOC_SEGMENT4="";
       obj.LOC_SEGMENT5="";
       obj.LOC_SEGMENT6="";
       obj.LOC_SEGMENT7="";
       obj.LOC_SEGMENT8="";
       obj.LOC_SEGMENT9="";
       obj.LOC_SEGMENT10="";
       obj.DST_SEGMENT1=element.dstSegment1;
       obj.DST_SEGMENT2=element.dstSegment2;
       obj.DST_SEGMENT3=element.dstSegment3;
       obj.DST_SEGMENT4="";
       obj.DST_SEGMENT5="";
       obj.DST_SEGMENT6="";
       obj.DST_SEGMENT7="";
       obj.DST_SEGMENT8="";
       obj.DST_SEGMENT9="";
       obj.DST_SEGMENT10="";
       obj.ShipToLocationId=""
       obj.UseCurrentCost= "Y";
       
       
           var availableQty = onhand.AvailableQuantity;
           console.log("AvailableQuantity:",availableQty); 
           console.log("remainingQyt--",remainingQty); 
           if(remainingQty>0){
              //This assumes that always project specific line will come first. The ordering of line is done in Report Query.
              if(availableQty>0){              
                if(remainingQty<=availableQty){
                console.log("Object Added when added qty is less then available qty");  
                console.log("onhand.ProjectId",onhand.ProjectId);
                if(onhand.ProjectId != 0){
                console.log("When projet is not null");                 
                obj.TransactionQuantity= (-1*remainingQty)+"";
                obj.ProjectID=bookoutHeaderType.projectIdVar;
                obj.ProjectNumber=bookoutHeaderType.projectNumberVar;
                obj.TaskID=bookoutHeaderType.taskIdVar;
                obj.TaskName= bookoutHeaderType.taskNumber;
                }else{
                console.log("When projet is  null")
                obj.TransactionQuantity= (-1*remainingQty)+"";
                obj.PjcProjectId= bookoutHeaderType.projectIdVar;
                obj.PjcProjectNumber=bookoutHeaderType.projectNumberVar;
                obj.PjcTaskId=bookoutHeaderType.taskIdVar;
				        obj.PjcTaskName= bookoutHeaderType.taskNumber;
				        obj.PjcContextCategory="INV_Misc_Transactions";
				        obj.PjcExpenditureItemDate=currDate;
				        obj.PjcExpenditureTypeId=element.pjcExpenditureTypeId;
				        obj.PjcOrganizationId=element.pjcOrganizationId;
                } 
                remainingQty=remainingQty-remainingQty;
                tempArray.push(obj);
                console.log('tempArray- ',tempArray); 
                }else{
                console.log("Object Added when added qty is more then available qty");
                console.log("onhand.ProjectId",onhand.ProjectId);
                if(onhand.ProjectId != 0){
                console.log("When projet is not null");
                obj.TransactionQuantity= (-1*availableQty)+"";
                obj.ProjectID=bookoutHeaderType.projectIdVar;
                obj.ProjectNumber=bookoutHeaderType.projectNumberVar;
                obj.TaskID=bookoutHeaderType.taskIdVar;
                obj.TaskName= bookoutHeaderType.taskNumber;
                }else{
                console.log("When projet is  null");
                obj.TransactionQuantity= (-1*remainingQty)+"";
                obj.PjcProjectId= bookoutHeaderType.projectIdVar;
                obj.PjcProjectNumber=bookoutHeaderType.projectNumberVar;
                obj.PjcTaskId=bookoutHeaderType.taskIdVar;
				        obj.PjcTaskName= bookoutHeaderType.taskNumber;
				        obj.PjcContextCategory="INV_Misc_Transactions";
				        obj.PjcExpenditureItemDate=currDate;
				        obj.PjcExpenditureTypeId=element.pjcExpenditureTypeId;
				        obj.PjcOrganizationId=element.pjcOrganizationId;
                } 
                remainingQty=remainingQty-availableQty;
                tempArray.push(obj); 
                console.log('tempArray- ',tempArray);
                }
              }
           }
         }
        } 
       }
       console.log('final tempArray- ',tempArray);
       if(transactionType == 'BOOKOUT_IN'){
           lineArr=tempArray; 
       }else{
         if(remainingQty>0){
          console.log('remainingQty- ',remainingQty); 
          }else{
           lineArr=tempArray; 
         }
       }
      
      console.log('lineArrt- ',lineArr);
      finalObj={"REQUEST_TYPE" : requestType,
                "TRX_DTL" : {
                  "line" :lineArr
                }
               }
      console.log('finalObj- ',finalObj);
      return finalObj;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    tempPrintData(arg1,arg2) {
      console.log('In tempPrintData');
      console.log(arg1);
      console.log(arg1.count);
      console.log(arg2);
      if(arg1 == null)
      console.log('Data is null');
      
      if(arg1 == '')
      console.log('Data is empty');

      if(arg1 == undefined)
      console.log('Data is undefined');
      
    }

    /**
     *
     * @param {String} This method is used to validate whether scanned item is PPE or TOOL or not.
     * @return {String}
     */
    checkForItemClassification(itemDFF) {
      var obj={};
      var flag = true;
      console.log("itemDFF - ",itemDFF,itemDFF.length);
      if(itemDFF.length>0){
        for(var element of itemDFF){
        console.log("flexContext - ",element.__FLEX_Context,element.ppeOrTool);
        var flexContext =element.__FLEX_Context;
        var ppeOrTool = element.ppeOrTool;
        if(flexContext == "ItemClassification" && (ppeOrTool =="P" || ppeOrTool =="T")){
          flag= false;
            obj={"status":"SUCCESS","value":ppeOrTool};
        }
      }
      if(flag){
          obj={"status":"ERROR","value":""};
        }
      }else{
        obj={"status":"ERROR","value":""};
      }
     return obj;
    }
    
    
    /**
     *
     * @param {String} setSegment1 and Location Code on Business unit selection event
     * @return {String}
     */
    fetchSegment1AndLocationcode(selectedNode,BUADP,bookoutHeaderType){
      console.log("selectedNode - ",selectedNode,BUADP,bookoutHeaderType)
      var filterdBUList = BUADP.filter(function (el) {
           console.log("Filter val before return->",el.ORGANIZATION_ID,selectedNode);
            return ((el.ORGANIZATION_ID == selectedNode))});
         console.log("new Array",filterdBUList,filterdBUList.length);
          for(var element of filterdBUList){
             console.log("element.Segment1",element.SEGMENT1,element.LOCATION_CODE,element.NAME);
            bookoutHeaderType.segment1=element.SEGMENT1;
            bookoutHeaderType.locationCodeVar = element.LOCATION_CODE;
            bookoutHeaderType.organizationName = element.NAME;
          }
         
      return bookoutHeaderType;
    }
    
    

    /**
     *
     * @param {String} set locator segment value on locator selection event
     * @return {String}
     */
    setLocatorSegmentVal(locatorADP,selectedVal,bookoutLineType) {
      console.log("selectedNode - ",locatorADP,selectedVal,bookoutLineType)
      var filterdLocatorList = locatorADP.filter(function (el) {
      console.log("Filter val before return->",el.INVENTORY_LOCATION_ID,selectedVal);
      return ((el.INVENTORY_LOCATION_ID == selectedVal))});
         console.log("new Array",filterdLocatorList,filterdLocatorList.length);
          for(var element of filterdLocatorList){
            console.log("element.Segment1",element.SEGMENT1,element.SEGMENT2,element.SEGMENT3);
            bookoutLineType.segment1=element.SEGMENT1;
            bookoutLineType.segment2 = element.SEGMENT2;
            bookoutLineType.segment3 = element.SEGMENT3;
          }
         
      return bookoutLineType;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    setTaskNumber(selectedVal,taskADP,bookoutHeaderType) {
      console.log("selectedNode - ",taskADP,selectedVal,bookoutHeaderType)
      var filterdTaskList = taskADP.filter(function (el) {
      console.log("Filter val before return->",el.TaskId,selectedVal);
      return ((el.TaskId == selectedVal))});
         console.log("new Array",filterdTaskList,filterdTaskList.length);
          for(var element of filterdTaskList){
            console.log("element.TaskNumber",element.TaskNumber);
            bookoutHeaderType.taskNumber=element.TaskNumber;
          }
         
      return bookoutHeaderType;
    }



    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    setDepartmentAttribute(selectedVal,deptADP,bookoutHeaderType) {
      console.log("selectedNode - ",deptADP,selectedVal,bookoutHeaderType)
      var filterdDeptList = deptADP.filter(function (el) {
      console.log("Filter val before return->",el.dept,selectedVal);
      return ((el.dept == selectedVal))});
         console.log("new Array",filterdDeptList,filterdDeptList.length);
          for(var element of filterdDeptList){
            console.log("element.Segment1",element.pjcOrganizationId,element.dept,element.exp_org);
            bookoutHeaderType.departmentVar=element.dept;
          }  
      return bookoutHeaderType;
    }
    
    getFormattedCurrentDate(){
      var today = new Date(); 
        var dd = today.getDate(); 
        var mm = today.getMonth() + 1; 
        var yyyy = today.getFullYear(); 
        if (dd < 10) { 
            dd = '0' + dd; 
        } 
        if (mm < 10) { 
            mm = '0' + mm; 
        } 
         today = yyyy+'-'+mm+'-'+dd; 
         return today;
    }
    

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    defaultExpenditureType(expenditureTypeADP,bookoutHeaderType) {
      console.log("selectedNode - ",expenditureTypeADP,bookoutHeaderType)
      var filterdExpenditureList = expenditureTypeADP.filter(function (el) {
      return ((el.ExpTypeName == "Materials"))});
         console.log("new Array",filterdExpenditureList,filterdExpenditureList.length);
          for(var element of filterdExpenditureList){
            console.log("element.Segment1",element.ExpTypeName,element.ExpTypeID);
            bookoutHeaderType.expenditureTypeId=element.ExpTypeID;
          }  
      return bookoutHeaderType;
    }

    /**
     *
     * @param {String} This method will valiate for mandatory fields in header and line tab conditionally for BKKOUOUT,BOOKOUT_OTHERS and BOOKIN transaction type
     * @return {String}
     */
    mandatoryFieldValidation(mandatoryFieldFlag,transactionType) {
      if(transactionType == 'BOOKOUT'){
        if(mandatoryFieldFlag.costCenterFieldFlag  || mandatoryFieldFlag.expenditireFieldFlag || mandatoryFieldFlag.taskFieldFlag || mandatoryFieldFlag.itemFieldFlag || mandatoryFieldFlag.subInvFieldFlag || mandatoryFieldFlag.locatorFieldFlag || mandatoryFieldFlag.invOrgFieldFlag ){
          return true;
        }
        
      }else if(transactionType == 'BOOKOUT_OTHERS'){
        if(mandatoryFieldFlag.costCenterFieldFlag || mandatoryFieldFlag.itemFieldFlag || mandatoryFieldFlag.subInvFieldFlag || mandatoryFieldFlag.locatorFieldFlag || mandatoryFieldFlag.invOrgFieldFlag ){
          return true;
        }
        
      }else if(transactionType == 'BOOKOUT_IN') {
        if(mandatoryFieldFlag.costCenterFieldFlag  || mandatoryFieldFlag.expenditireFieldFlag || mandatoryFieldFlag.taskFieldFlag || mandatoryFieldFlag.itemFieldFlag || mandatoryFieldFlag.subInvFieldFlag || mandatoryFieldFlag.locatorFieldFlag || mandatoryFieldFlag.invOrgFieldFlag ){
          return true;
        }
      }
      return false;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    validateOnAddButtonClick(transactionType,qtyAdded,qtyAvailable,mandatoryFieldFlag) {
      console.log("qtyAdded ,transactionType",qtyAdded,transactionType);
      var isMandatoryFieldValidated = this.mandatoryFieldValidation(mandatoryFieldFlag,transactionType)
      if(isMandatoryFieldValidated){
         return "M";
      }
      if(transactionType !='BOOKOUT_IN'){
        if(qtyAdded!=null && qtyAdded!=0){
        if(qtyAdded>qtyAvailable){
          return "Q";
        }
      }else{
        return "Q";
      }
      }else{
         if( qtyAdded==0){
            return "Q";
         }
      }

       return "S";
      
    }
    
    
    
    /**
     * This method will populate available quantity while editing item details.
     * @param {String} arg1 - bookout itemonhand rest rervice response
     * @return {String}
     */
    getUpdatedAvailableQuantity(itemQtyList) {
       var totalQuantity = 0;
       var availableQty = 0;
       for(var element of itemQtyList){
          var taskNumber="0";
          var projectNumber = 0;
          console.log('Element - ',element);
          availableQty = element.PRIMARY_TRANSACTION_QUANTITY - element.PENDING_TRANSACTION_COUNT - element.RESERVED_TRANSACTION_COUNT;
          totalQuantity = totalQuantity + availableQty;
          
      }
       return totalQuantity;
    }
    
    

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    itemScannerFunction(arg1) {
      var barcodeScannerPromise = new Promise(function (resolve, reject) {
      window.cordova.plugins.barcodeScanner.scan(
      function (result) {
//           alert("We got a barcode\n" +
//                 "Result: " + result.text + "\n" +
//                 "Format: " + result.format + "\n" +
//                 "Cancelled: " + result.cancelled);
				 resolve(result.text); 
      },
      function (error) {
//           alert("Scanning failed: " + error);
		  reject(error);
       });
	   });
	    console.log("Scanning result: ",barcodeScannerPromise);
	  
       return barcodeScannerPromise;  
    }
  }

  return PageModule;
});
