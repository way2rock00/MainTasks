define(['vb/test/TestUtils'], function(TestUtils) {
    'use strict';

    describe('mobileApps/ee_mobileapplication/flows/inventory/pages/inv_project_search_page-page', function() {

    });
});