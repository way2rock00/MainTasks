define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    populateItemSearchListForPpeAndTool(itemServiceResponseList) {
      console.log("itemServiceResponseList ",itemServiceResponseList);
      var arr=[];
      for(var element of itemServiceResponseList){      
        var itemDff    = element.ItemDFF;
        console.log("itemDFF - ",itemDff);
        if(itemDff.length>0){
          for(var dffElement of itemDff){
            console.log("flexContext - ",dffElement.__FLEX_Context,dffElement.ppeOrTool);
            var flexContext =dffElement.__FLEX_Context;
            var ppeOrTool = dffElement.ppeOrTool;
            if(flexContext == "ItemClassification" && (ppeOrTool =="P" || ppeOrTool =="T")){
            console.log("Item object added in list");
            arr.push(element);
        }
       }
      }
      }

     console.log("arr ",arr);
     return arr;
  }


    

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    scanItemDetailsFunction(arg1) {
      var barcodeScannerPromise = new Promise(function (resolve, reject) {
      window.cordova.plugins.barcodeScanner.scan(
      function (result) {
//           alert("We got a barcode\n" +
//                 "Result: " + result.text + "\n" +
//                 "Format: " + result.format + "\n" +
//                 "Cancelled: " + result.cancelled);
				 resolve(result.text); 
      },
      function (error) {
//           alert("Scanning failed: " + error);
		  reject(error);
       });
	   });
        return barcodeScannerPromise;  
    }
}
  return PageModule;
});
