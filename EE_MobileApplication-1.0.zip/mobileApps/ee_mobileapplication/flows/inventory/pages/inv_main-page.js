define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    populateTransactionType(arg1) {
      
       console.log('In populateTransactionType',arg1);
      if(arg1 == 'BOOKOUT' )
      return 'Bookout';
       if(arg1 == 'BOOKOUT_OTHERS' )
      return 'Bookout Tools/PPE';
      if(arg1 == 'BOOKOUT_IN' )
      return 'Book In';
      
    }
  }

  return PageModule;
});
