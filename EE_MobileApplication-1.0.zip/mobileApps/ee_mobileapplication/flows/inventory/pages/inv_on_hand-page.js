define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printData(arg1,arg2) {
      console.log(arg1);
      var totalQuantity = 0;
      for(var element of arg1){
        console.log('Debug->', element.PRIMARY_TRANSACTION_QUANTITY , element.PENDING_TRANSACTION_COUNT,element.RESERVED_TRANSACTION_COUNT);
        element.AVAILABLE_QUANTITY = element.PRIMARY_TRANSACTION_QUANTITY - element.PENDING_TRANSACTION_COUNT - element.RESERVED_TRANSACTION_COUNT;
        totalQuantity = totalQuantity + element.AVAILABLE_QUANTITY;
        console.log('Debug->',element.AVAILABLE_QUANTITY,totalQuantity);
      }
      console.log('After update');
      console.log(arg1);
      var retData = {};
      retData.totalQuantity = totalQuantity;
      retData.arrayData = arg1;
      arg2 = totalQuantity;
      console.log(totalQuantity, arg2)
      /*return retData; */
      return totalQuantity;
    }
  
  printEPData(arg1){
    console.log(arg1);
  }
}

  return PageModule;
});
