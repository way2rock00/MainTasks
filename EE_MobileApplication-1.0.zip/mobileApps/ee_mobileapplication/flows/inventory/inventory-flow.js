define([], () => {
  'use strict';

  class FlowModule {

  
              /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printData(arg1) {
            console.log("seelct Project List response --> ",arg1);
            console.log('response length',arg1.length);
             for (var key in arg1) {
               var val = arg1[key];   
                 console.log('key - ',key);
                   console.log('val - ',val);  
             }

    }
    
  }
  
 

  return FlowModule;
});
