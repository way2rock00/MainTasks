define([], () => {
  'use strict';

  class StartModule {
  }

  return StartModule;
});
