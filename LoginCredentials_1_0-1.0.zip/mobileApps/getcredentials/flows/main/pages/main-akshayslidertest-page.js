define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printListData(arg1) {
      console.log('In printListData',arg1);
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    setValue(arg1,arg2,arg3,arg4) {
      console.log('In setValue');
      console.log('arg1',arg1);
      console.log('arg2',arg2);
      console.log('arg3',arg3);
      console.log('arg4',arg4);
      
    }
  }

  return PageModule;
});
