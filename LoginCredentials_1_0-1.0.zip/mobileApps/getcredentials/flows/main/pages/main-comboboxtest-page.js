define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printData(arg1,arg2,arg3) {
      console.log('In PrintData');
      console.log(arg1);
      console.log(arg2);
      console.log(arg3);
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printSelectedValue(arg1) {
      console.log('In printSelectedValue');
      console.log(arg1);
    }
  }

  return PageModule;
});
