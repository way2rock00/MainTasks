define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
  

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
      sum(arg1) {
      var add=0;
      for (var i = 0; i < arg1.length  ; i++ )
      {
        add = add + arg1[i].Quantity;
        }
        console.log(add);
        return add;
    }
    

 }
 
 
 
  return PageModule;
});
