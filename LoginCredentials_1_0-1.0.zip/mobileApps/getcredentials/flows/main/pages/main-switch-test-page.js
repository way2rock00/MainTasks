define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    loadData1(arg1) {
      console.log('In loadData1:Start:'+new Date());
      var a = [];
      for(var i=0;i<1000;i++){
        
        a.push('Data:'+i);
        //setTimeout(function(){console.log('Test1');}, 20000); 
      }
      console.log('In loadData1:End:'+new Date());
      return a;
      
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    loadData2(arg1) {
      console.log('In loadData2:Start:'+new Date());
      var a = [];
      for(var i=5000;i<2000;i++){
        
        a.push('Data:'+i);
        //setTimeout(function(){console.log('Test2');}, 50000); 
      }
      console.log('In loadData2:End:'+new Date());      
      return a;
      
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    loadData3(arg1) {
      console.log('In loadData3:Start:'+new Date());
      var a = [];
      for(var i=10000;i<30;i++){
        
        a.push('Data:'+i);
        setTimeout(function(){console.log('Test3');}, 30000); 
      }
      console.log('In loadData3:End:'+new Date());      
      return a;
      
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    mergeData(arg1,arg2,arg3) {
      console.log('In loadData4:Start:'+new Date());
      console.log('arg1',arg1);
      console.log('arg2',arg2);
      console.log('arg3',arg3);
      console.log('In mergeData:End:'+new Date());
    }
  }

  return PageModule;
});
