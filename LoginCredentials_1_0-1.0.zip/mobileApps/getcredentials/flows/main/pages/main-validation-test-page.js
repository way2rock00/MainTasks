define(['ojs/ojmessaging'], (Message) => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    testData(arg1) {
      console.log('In testData');
      console.log(arg1);
      var message1 =  new Message('Test', 'Test', Message.ERROR);
      arg1.push(message1);
      var a = document.getElementById('mainValidationGroup');
      console.log(arg1);
      console.log(a);
      console.log(a.valid);
      if(a.valid==='valid'){
        console.log('Do action that we will perform on valid thing.');
        console.log('This function here can return true which can trigger next action in action chain.');
      }else{
        a.showMessages();
        a.focusOn("@firstInvalidShown");
        console.log('There is error');
      }
      return arg1
     
    }
    
    showCustomError(arg1) {
       console.log('In showCustomError');
       console.log('These errors will not be shown on screen. But it will shown in the console.log')
       throw new Error('Error hi error'); 
    }
    
    customValidator(){
      var a = {};
      a.name = 'Akshay';
      a.age = '20';
      var arr = [];
      arr.push(a);
      return arr;
      /*return[
        {
        validate: function(inp1){
          console.log('In Validator. ',inp1);
          return true;
        }        
      }
     ]*/
    }
    
    endDateAfterStartDateValidator(startDate) {
      console.log('In endDateAfterStartDateValidator:',startDate);
    return [{
      validate: (endDate) => {
        console.log('Function1');
        console.log(endDate);
        if (endDate) {
          const valid = endDate >= startDate;
          if (!valid) {
            throw new Error('End date must be start date or later:'+endDate);
          }
          return false;
        }
      }
    },
    {
      validate: (endDate) => {
        console.log('Function2');
        console.log(endDate);
        if (endDate) {
          const valid = endDate >= startDate;
          if (!valid) {
            throw new Error('End date must be start date or later 123:'+endDate);
          }
          return false;
        }
      },
    }
    ];
  };
    
    

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    generateDate(arg1) {
      console.log('In generateDate');
      var d = new Date();
      console.log(d);
    }
  }

  return PageModule;
});
