define([], function(){
  'use strict';

 class PageModule {
   }
 

  
  return PageModule;
});


 