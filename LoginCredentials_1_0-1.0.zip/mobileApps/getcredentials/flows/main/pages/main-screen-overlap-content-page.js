define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    sideBarMenu(arg1) {
      console.log('In SideBar menu');
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    topMenu(arg1) {
      var d = document.getElementById('leftDrawer');
      var m = document.getElementById('mainContent');
      console.log('In topMenu');
      console.log(d);
      console.log(d.classList);
      if (d.classList.contains("show-drawer")) {
          d.classList.remove("show-drawer");
          m.classList.remove("hide-main-content");
        } else {
          d.classList.add("show-drawer");
          m.classList.add("hide-main-content");
        }
    }
  }

  return PageModule;
});
