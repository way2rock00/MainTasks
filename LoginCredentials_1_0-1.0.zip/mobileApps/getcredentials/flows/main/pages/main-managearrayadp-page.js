define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printData(arg1) {
      console.log('In printData',arg1);
    }
    
     addData(arg1) {
      console.log('In addData',arg1);
      var obj = {};
      obj.headerId = 5;
      obj.headerName = "Object 1";
      obj.headerText = "Main Object Value"
      arg1.push(obj);
      console.log('In addData: After ',arg1);
      return arg1;
    }
  }

  return PageModule;
});
