define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printData(arg1,arg2,arg3,arg4) {
      console.log('In printData ******************************** ');
      console.log(arg1);
      console.log(arg2);
      console.log(arg3);
      console.log(arg4);
      
//       for(var ele of arg4){
//         console.log('Element Value:'+ele.empId+' '+ele.empFirstName);
//       }
      //return arg4;
      var a = {};
      var data = [];
      arg3 = arg3 + 1;
      a.empId = 1001;
      a.empFirstName = arg2.firstName;
      a.empSecondName = arg2.lastName;
      a.recordId = 2;
      a.salary = arg2.salary;
      a.type = 'Test';    
      
      data.push(a);
      console.log(data);
//       var result = {};
//       result.data = data;
//       result.counter = arg3;
//       console.log('Result Object:---->',result);
      return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    newPrintData(arg4) {
      console.log('In newPrintData ******************************** ');
      console.log('In newPrintData New ******************************** ');
      console.log(arg4);
      console.log(arg4);
      console.log(arg4);
      
      for(var i=0;i<arg4.length;i++){
        
        console.log(arg4[i].empFirstName);
        arg4[i].empId = 1000;
        arg4[i].salary = arg4[i].salary + 100;
      }
//       for(var ele of arg4){
//         console.log('Element Value:'+ele.empId+' '+ele.empFirstName);
//         console.log(ele);
//         
//       }
      return arg4;
    }
  }

  return PageModule;
});
