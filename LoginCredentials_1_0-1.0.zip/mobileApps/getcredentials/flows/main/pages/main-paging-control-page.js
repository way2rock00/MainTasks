define(['ojs/ojpagingdataproviderview', 'ojs/ojarraydataprovider'], (PagingDataProviderView, ArrayDataProvider) => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    modifyData(arg1) {
      
      return new PagingDataProviderView(new ArrayDataProvider(arg1, { idAttribute: 'empId' }));
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printData(arg1,arg2,arg3,arg4) {
      console.log('In printData: arg1:',arg1);
      console.log('In printData: arg2:',arg2);
      console.log('In printData: arg3:',arg3);
      console.log('In printData: arg4:',arg4);
    }

    /**
     *
     * @param {String} arg1
     * @return {String}x
     */
    dummy(arg1) {
      console.log('In dummy: arg1:'+arg1);
    }
  }

  return PageModule;
});
