define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printData(arg1,arg2,arg3,arg4) {
      console.log('In printData');
      console.log(arg1);
      console.log(arg2);
      console.log(arg3);
      console.log(arg4);
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    assignCollection(arg1) {
      console.log('In assignCollection',arg1);
      var ret = [];
              if(arg1 == 'India')  {
          var a = {};
          a.cityId = 1;
          a.cityName = "Mumbai";
          ret.push(a);
          a.cityId = 2;
          a.cityName = "Delhi";
          ret.push(a);

        }else{
          var a = {};
          a.cityId = 1;
          a.cityName = "Florida";
          ret.push(a);
          a.cityId = 2;
          a.cityName = "New York";
          ret.push(a);


        }
              console.log(ret);

        return ret;
    }
  }

  return PageModule;
});
