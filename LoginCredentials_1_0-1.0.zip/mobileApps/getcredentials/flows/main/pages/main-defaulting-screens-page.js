define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printDateVar(arg1) {
      console.log('In printDateVar',arg1);
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printMainContent(arg1) {
      console.log('In printMainContent');
      console.log(arg1);
    }
  }

  return PageModule;
});
