define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    showErrorMessage(arg1) {
      setTimeout(function(){console.log('***************************')}, 80000);
    }
  }

  return PageModule;
});
