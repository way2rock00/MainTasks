define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    testMF(arg1) {
      console.log('testMF',arg1);
    }
  }

  return PageModule;
});
