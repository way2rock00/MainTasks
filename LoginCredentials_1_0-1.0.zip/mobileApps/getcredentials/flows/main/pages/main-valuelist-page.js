define(['knockout', 'ojs/ojbootstrap', 'ojs/ojarraydataprovider', 'ojs/ojknockout', 'ojs/ojselectcombobox'], 
  function (ko, BootStrap, ArrayDataProvider,) {
  'use strict';
  
  function ComboboxModel() {
      this.browsers = [
        { value: 'Internet Explorer', label: 'Internet Explorer', image: '../images/internet-explorer.png' },
        { value: 'Firefox', label: 'Firefox', image: '../images/firefox.png' },
        { value: 'Chrome', label: 'Chrome', image: '../images/chrome.png' },
        { value: 'Opera', label: 'Opera', image: '../images/opera.png' },
        { value: 'Safari', label: 'Safari', image: '../images/safari.png' }
      ];
  
      this.browsersDP = new ArrayDataProvider(this.browsers, { keyAttributes: 'value' });
  
      this.optionRenderer = function(context) {
        var data = context.data;
  
        var optionElem = document.createElement('oj-option');
  
        var labelElem = document.createElement('span');
        labelElem.innerHTML = data.label;
  
       
        optionElem.appendChild(labelElem);
  
        return optionElem;
      };
    }
   BootStrap.whenDocumentReady().then(function () {
      ko.applyBindings(new ComboboxModel(), document.getElementById('containerDiv'));
    });

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    EmpListDisplay(arg1) {
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    workWithCollection(arg1,arg2) {
      console.log('In workWithCollection');
      console.log(arg1);
      console.log(arg2);
    }
  }

  return PageModule;
});
