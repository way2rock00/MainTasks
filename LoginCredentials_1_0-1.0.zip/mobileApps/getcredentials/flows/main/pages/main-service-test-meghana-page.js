define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printData(arg1) {
      console.log(arg1);
    }
  }

  return PageModule;
});
