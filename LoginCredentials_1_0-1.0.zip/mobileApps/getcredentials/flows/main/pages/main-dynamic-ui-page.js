define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    showTest(arg1) {
    
      console.log('Akshay');
    }
  }

  return PageModule;
});
