define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    printData(arg1) {
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    customizedActionChain(arg1) {
      console.log('***********************************************In customizedActionChain************************************');
      console.log(arg1);
    }
  }

  return PageModule;
});
